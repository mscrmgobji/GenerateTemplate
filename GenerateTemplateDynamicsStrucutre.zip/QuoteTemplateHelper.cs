﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentrixBI_OneShot.QuoteTemplate
{

    public static class QuoteTemplateHelper
    {
        /// <summary>
        /// Traduit une exception en quote template d'erreur :
        ///   • erreur fonctionnelle → ctx_name = nom de l'erreur métier
        ///   • autre exception      → ctx_name = type de l'exception (ex : NullReferenceException)
        /// </summary>
        public static void HandleException(IOrganizationService service, ref TraceLogger log, Guid quoteId, Exception ex)
        {
            string errorName;
            string errorMessage;

            if (ex is QuoteTemplateFunctionalException fex)
            {
                errorName = fex.ErrorName;
                errorMessage = fex.Message;
            }
            else
            {
                errorName = ex.GetType().Name;
                errorMessage = ex.Message;
                if (ex.InnerException != null)
                    errorMessage += $" | Inner exception: {ex.InnerException.Message}";
            }

            log.Trace($"⚠️ Exception [{errorName}] : {errorMessage}");
            CreateErrorTemplate(service, ref log, quoteId, errorName, errorMessage);
        }

        /// <summary>
        /// Retourne les règles applicables au pays de la liste de prix, dans l'ordre du paramétrage.
        /// Les FetchXml sont exécutés ici (un appel par règle FetchXml) ; les règles "ProductNames" ne font aucun appel.
        /// </summary>
        public static List<ResolvedAdditionalProductRule> ResolveAdditionalProductRules(IOrganizationService service, ref TraceLogger log, string countryName, Guid quoteId, Guid? priceLevelId)
        {
            var result = new List<ResolvedAdditionalProductRule>();
            var rules = AdditionalProductsConfig.GetRulesForCountry(countryName);
            log.Trace($"Règles produits additionnels applicables (pays '{countryName ?? "non défini"}') : {rules.Count}");

            foreach (var rule in rules)
            {
                if (!rule.HasNameCriteria && !rule.HasFetchCriteria)
                {
                    log.Trace($"Règle slot {rule.AdditionalProductNum} : ni ProductNames ni FetchXml — ignorée");
                    continue;
                }

                var resolved = new ResolvedAdditionalProductRule { Rule = rule };

                if (rule.HasNameCriteria)
                {
                    log.Trace($"Règle slot {rule.AdditionalProductNum} : critère nom → {string.Join(", ", rule.ProductNames)}");
                }

                if (rule.HasFetchCriteria)
                {
                    var fetchXml = rule.FetchXml
                        .Replace("{quoteid}", quoteId.ToString())
                        .Replace("{pricelevelid}", priceLevelId?.ToString() ?? Guid.Empty.ToString());

                    EntityCollection records;
                    try
                    {
                        records = service.RetrieveMultiple(new FetchExpression(fetchXml));
                    }
                    catch (Exception ex)
                    {
                        throw new QuoteTemplateFunctionalException(
                            QuoteTemplateErrors.ParametrageProduitAdditionnel,
                            $"Invalid FetchXml for additional product {rule.AdditionalProductNum} (country '{rule.Country}'): {ex.Message}");
                    }

                    foreach (var record in records.Entities)
                    {
                        var productId = GetProductId(record);
                        if (productId.HasValue)
                            resolved.ProductIds.Add(productId.Value);
                        else
                            log.Trace($"Règle slot {rule.AdditionalProductNum} : résultat '{record.LogicalName}' sans productid — ignoré");
                    }

                    log.Trace($"Règle slot {rule.AdditionalProductNum} : FetchXml → {resolved.ProductIds.Count} produit(s)");
                }

                result.Add(resolved);
            }

            return result;
        }

        /// <summary>
        /// Crée UN SEUL ctx_quotetemplate d'erreur pour le devis :
        /// supprime d'abord les templates existants, puis crée l'enregistrement avec ctx_name = nom de l'erreur
        /// et le message dans le champ d'erreur.
        /// </summary>
        public static void CreateErrorTemplate(IOrganizationService service, ref TraceLogger log, Guid quoteId, string errorName, string errorMessage)
        {
            try
            {
                // Garantir un seul enregistrement : supprimer tout template déjà présent pour ce devis
                var existing = service.RetrieveMultiple(new QueryExpression("ctx_quotetemplate")
                {
                    ColumnSet = new ColumnSet("ctx_quotetemplateid"),
                    Criteria = { Conditions = { new ConditionExpression("ctx_quoteid", ConditionOperator.Equal, quoteId) } }
                }).Entities;

                foreach (var record in existing)
                {
                    service.Delete("ctx_quotetemplate", record.Id);
                }

                string message = errorMessage ?? string.Empty;
                if (message.Length > QuoteTemplateErrors.ErrorMessageMaxLength)
                    message = message.Substring(0, QuoteTemplateErrors.ErrorMessageMaxLength);

                var errorTemplate = new Entity("ctx_quotetemplate");
                errorTemplate["ctx_name"] = errorName;
                errorTemplate["ctx_quoteid"] = new EntityReference("quote", quoteId);
                errorTemplate[QuoteTemplateErrors.ErrorMessageField] = message;

                var id = service.Create(errorTemplate);
                log.Trace($"ctx_quotetemplate d'erreur créé ({id}) : [{errorName}] {message}");
            }
            catch (Exception ex)
            {
                // Impossible d'enregistrer l'erreur (ex : champ absent) → on trace et on sort sans bloquer l'utilisateur
                log.Trace($"Échec de création du ctx_quotetemplate d'erreur : {ex.Message} — erreur d'origine : [{errorName}] {errorMessage}");
            }
        }

        /// <summary>
        /// Libellé d'un champ Choix multiple (ex : "Platform A; Platform B"), lu depuis les FormattedValues.
        /// Fonctionne aussi pour une colonne de lien (clé "alias.champ").
        /// </summary>
        public static string GetMultiSelectLabel(Entity record, string key)
        {
            if (record == null || string.IsNullOrEmpty(key)) return null;

            if (record.FormattedValues.ContainsKey(key) && !string.IsNullOrWhiteSpace(record.FormattedValues[key]))
                return record.FormattedValues[key];

            // Repli : valeurs numériques si le libellé n'est pas disponible
            if (record.Contains(key))
            {
                var raw = record[key];
                if (raw is AliasedValue aliased) raw = aliased.Value;
                if (raw is OptionSetValueCollection values && values.Count > 0)
                    return string.Join("; ", values.Select(v => v.Value.ToString()));
            }
            return null;
        }

        /// <summary>
        /// Nom du produit à afficher (compatibilité) : voir ResolveProductByExternalId.
        /// </summary>
        public static string ResolveProductNameByExternalId(IOrganizationService service, ref TraceLogger log, Guid productId, Dictionary<Guid, Entity> productCache)
        {
            return ResolveProductByExternalId(service, ref log, productId, productCache)?.Name;
        }

        /// <summary>
        /// On part du produit et on remonte la hiérarchie (parent, grand-parent…) jusqu'au premier produit
        /// dont ctx_externalid est renseigné. Retourne l'Id ET le nom de ce produit
        /// (l'Id sert à la traduction ctx_productcountryname).
        /// Retourne null si aucun produit de la hiérarchie n'a de ctx_externalid.
        /// </summary>
        public static ResolvedProduct ResolveProductByExternalId(IOrganizationService service, ref TraceLogger log, Guid productId, Dictionary<Guid, Entity> productCache)
        {
            var visited = new HashSet<Guid>();
            Guid? currentId = productId;
            int level = 0;

            while (currentId.HasValue && level <= QuoteTemplateFields.MaxProductHierarchyDepth)
            {
                // Protection contre une boucle dans la hiérarchie
                if (!visited.Add(currentId.Value))
                {
                    log.Trace($"Hiérarchie produit {productId} : boucle détectée sur {currentId.Value} — arrêt");
                    break;
                }

                var product = GetProductForHierarchy(service, currentId.Value, productCache);
                if (product == null) break;

                string externalId = product.GetAttributeValue<string>(QuoteTemplateFields.ProductExternalId);
                string name = product.GetAttributeValue<string>("name");

                if (!string.IsNullOrWhiteSpace(externalId))
                {
                    log.Trace($"Produit {productId} : produit résolu = '{name}' ({currentId.Value}, niveau {level}, ctx_externalid = '{externalId}')");
                    return new ResolvedProduct { Id = currentId.Value, Name = name };
                }

                currentId = product.GetAttributeValue<EntityReference>("parentproductid")?.Id;
                level++;
            }

            log.Trace($"Produit {productId} : aucun ctx_externalid dans la hiérarchie");
            return null;
        }

        /// <summary>Produit (name, parentproductid, ctx_externalid) depuis le cache, sinon Retrieve puis mise en cache.</summary>
        public static Entity GetProductForHierarchy(IOrganizationService service, Guid productId, Dictionary<Guid, Entity> productCache)
        {
            if (productCache.TryGetValue(productId, out var cached)) return cached;

            var product = service.Retrieve("product", productId,
                new ColumnSet("name", "parentproductid", QuoteTemplateFields.ProductExternalId));
            productCache[productId] = product;
            return product;
        }

        /// <summary>Ajoute au cache le produit lu via une jointure (alias "product" ou "familyproduct").</summary>
        public static void CacheProductFromAlias(Dictionary<Guid, Entity> productCache, Entity line, string alias)
        {
            var id = GetAliasedValue<Guid?>(line, alias + ".productid");
            if (!id.HasValue || productCache.ContainsKey(id.Value)) return;

            var product = new Entity("product", id.Value);
            product["name"] = GetAliasedValue<string>(line, alias + ".name");
            product["parentproductid"] = GetAliasedValue<EntityReference>(line, alias + ".parentproductid");
            product[QuoteTemplateFields.ProductExternalId] = GetAliasedValue<string>(line, alias + "." + QuoteTemplateFields.ProductExternalId);
            productCache[id.Value] = product;
        }

        /// <summary>Valeur d'une colonne de lien (AliasedValue), default(T) si absente ou NULL.</summary>
        public static T GetAliasedValue<T>(Entity record, string key)
        {
            if (record == null || string.IsNullOrEmpty(key) || !record.Contains(key) || record[key] == null) return default(T);

            var raw = record[key];
            if (raw is AliasedValue aliased) raw = aliased.Value;
            return raw is T typed ? typed : default(T);
        }

        /// <summary>Ajoute une famille (sans doublon) dans ctx_productfamily du template.</summary>
        public static void AddProductFamily(Entity template, string family)
        {
            if (template == null || string.IsNullOrWhiteSpace(family)) return;

            var existing = template.GetAttributeValue<string>(QuoteTemplateFields.ProductFamily);
            var labels = (existing ?? string.Empty)
                .Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(l => l.Trim())
                .ToList();

            foreach (var label in family.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries).Select(l => l.Trim()))
            {
                if (!labels.Contains(label, StringComparer.OrdinalIgnoreCase)) labels.Add(label);
            }

            template[QuoteTemplateFields.ProductFamily] = string.Join("; ", labels);
        }

        /// <summary>GUID du produit : Id si l'entité est un product, sinon l'attribut productid.</summary>
        public static Guid? GetProductId(Entity record)
        {
            if (record.LogicalName == "product") return record.Id;

            if (record.Contains("productid"))
            {
                var raw = record["productid"];
                if (raw is AliasedValue aliased) raw = aliased.Value;
                if (raw is EntityReference er) return er.Id;
                if (raw is Guid g) return g;
            }
            return null;
        }

        /// <summary>
        /// Indique si le champ du quotedetail est de type Currency (Money).
        /// Basé sur les métadonnées (fonctionne aussi quand la valeur est NULL), résultat mis en cache.
        /// </summary>
        public static bool IsCurrencyField(IOrganizationService service, ref TraceLogger log, Entity line, string fieldName, Dictionary<string, bool> cache)
        {
            if (string.IsNullOrWhiteSpace(fieldName)) return false;
            fieldName = fieldName.Trim().ToLowerInvariant();

            // Valeur présente et de type Money → pas besoin des métadonnées
            if (line != null && line.Contains(fieldName))
            {
                var raw = line[fieldName];
                if (raw is AliasedValue aliased) raw = aliased.Value;
                if (raw is Money) return true;
            }

            if (cache.TryGetValue(fieldName, out bool isMoney)) return isMoney;

            try
            {
                var response = (RetrieveAttributeResponse)service.Execute(new RetrieveAttributeRequest
                {
                    EntityLogicalName = "quotedetail",
                    LogicalName = fieldName,
                    RetrieveAsIfPublished = false
                });
                isMoney = response.AttributeMetadata?.AttributeType == AttributeTypeCode.Money;
            }
            catch (Exception ex)
            {
                log.Trace($"Impossible de lire les métadonnées du champ quotedetail.{fieldName} : {ex.Message}");
                isMoney = false;
            }

            cache[fieldName] = isMoney;
            return isMoney;
        }

        /// <summary>Symbole de la devise du devis (quote.transactioncurrencyid → transactioncurrency.currencysymbol).</summary>
        public static string GetQuoteCurrencySymbol(IOrganizationService service, ref TraceLogger log, Guid quoteId)
        {
            try
            {
                var quoteEntity = service.Retrieve("quote", quoteId, new ColumnSet("transactioncurrencyid"));
                var currencyRef = quoteEntity.GetAttributeValue<EntityReference>("transactioncurrencyid");
                if (currencyRef == null)
                {
                    log.Trace("Le devis n'a pas de devise (transactioncurrencyid)");
                    return null;
                }

                var currency = service.Retrieve("transactioncurrency", currencyRef.Id, new ColumnSet("currencysymbol"));
                var symbol = currency.GetAttributeValue<string>("currencysymbol");
                log.Trace($"Symbole de devise du devis : '{symbol}'");
                return symbol;
            }
            catch (Exception ex)
            {
                log.Trace($"Erreur lors de la récupération du symbole de devise : {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Formate un champ Currency : "251,000.00 €" (format #,##0.00, InvariantCulture).
        /// Valeur NULL → "- €".
        /// </summary>
        public static string FormatCurrencyValue(Entity line, string fieldName, string currencySymbol)
        {
            decimal? amount = null;
            fieldName = fieldName?.Trim().ToLowerInvariant();

            if (line != null && !string.IsNullOrEmpty(fieldName) && line.Contains(fieldName) && line[fieldName] != null)
            {
                var raw = line[fieldName];
                if (raw is AliasedValue aliased) raw = aliased.Value;
                if (raw is Money m) amount = m.Value;
                else if (raw is decimal d) amount = d;
            }

            string amountText = amount.HasValue
                ? amount.Value.ToString("#,##0.00", CultureInfo.InvariantCulture)
                : "-";

            return string.IsNullOrEmpty(currencySymbol) ? amountText : $"{amountText} {currencySymbol}";
        }

        /// <summary>Convertit la valeur d'un champ du quotedetail en texte (pour ctx_additionalproductNvalue).</summary>
        public static string GetFieldValueAsText(Entity line, string fieldName)
        {
            if (line == null || string.IsNullOrWhiteSpace(fieldName)) return null;
            fieldName = fieldName.Trim().ToLowerInvariant();
            if (!line.Contains(fieldName) || line[fieldName] == null) return null;

            var raw = line[fieldName];
            if (raw is AliasedValue aliased) raw = aliased.Value;

            switch (raw)
            {
                case Money m: return Math.Round(m.Value, 2).ToString();
                case decimal d: return Math.Round(d, 2).ToString();
                case double db: return Math.Round(db, 2).ToString();
                case OptionSetValue o: return line.FormattedValues.ContainsKey(fieldName) ? line.FormattedValues[fieldName] : o.Value.ToString();
                case EntityReference r: return r.Name ?? r.Id.ToString();
                case bool b: return line.FormattedValues.ContainsKey(fieldName) ? line.FormattedValues[fieldName] : b.ToString();
                default: return raw.ToString();
            }
        }

    }

    /// <summary>Produit de la hiérarchie qui porte le ctx_externalid : son Id (traduction) et son nom (ctx_name).</summary>
    public class ResolvedProduct
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }

    /// <summary>Champs liés à la famille de produit.</summary>
    public static class QuoteTemplateFields
    {
        // Nouveau champ texte sur ctx_quotetemplate
        public const string ProductFamily = "ctx_productfamily";

        // Produits hors catalogue : nom par défaut si productname et productdescription sont vides,
        // et longueur max de ctx_name (⚠️ à aligner sur la longueur réelle du champ dans Dataverse)
        public const string WriteInDefaultName = "Write-in product";
        public const int NameMaxLength = 100;

        // Nom des produits : premier produit de la hiérarchie ayant un ctx_externalid (champ texte sur product)
        public const string ProductExternalId = "ctx_externalid";
        public const int ProductTypeCodeProduct = 1;         // quotedetail.producttypecode = Product
        public const int MaxProductHierarchyDepth = 20;      // sécurité : nombre max de niveaux remontés

        // Champ Choix multiple sur product
        public const string ProductPlatformList = "ctx_platformlist";

        // Bundles : on ne garde que les produits dont ctx_platformlist contient une de ces valeurs
        public static readonly int[] BundlePlatformListValues = { 961410000, 961410001 };
    }

    /// <summary>Noms des erreurs fonctionnelles (stockés dans ctx_name) + champ du message.</summary>
    public static class QuoteTemplateErrors
    {
        // ⚠️ Nom logique du nouveau champ texte à créer sur ctx_quotetemplate (Plusieurs lignes de texte, 4000)
        public const string ErrorMessageField = "ctx_errormessage";
        public const int ErrorMessageMaxLength = 4000;

        public const string DoublonProduitZone = "Duplicate product / zone";
        public const string ListePrixManquante = "Missing price list";
        public const string ParametrageProduitAdditionnel = "Invalid additional product configuration";
    }

    /// <summary>Erreur fonctionnelle : ne bloque pas l'utilisateur, génère un ctx_quotetemplate d'erreur.</summary>
    public class QuoteTemplateFunctionalException : Exception
    {
        public string ErrorName { get; }

        public QuoteTemplateFunctionalException(string errorName, string message) : base(message)
        {
            ErrorName = errorName;
        }
    }
}
