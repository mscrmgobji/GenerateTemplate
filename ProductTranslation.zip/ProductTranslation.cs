﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentrixBI_OneShot.QuoteTemplate
{
    public static class ProductTranslation
    {

        public static Entity GetProductTranslationName(IOrganizationService service, Guid countryId, Guid productId, TraceLogger log)
        {
            try
            {
                log.Trace("Start de GetProductTranslationName pour country : {0} et product : {1}", countryId, productId);

                QueryExpression queryLocalName = new QueryExpression("ctx_producttranslation")
                {
                    ColumnSet = new ColumnSet("ctx_name"),
                    TopCount = 1
                };

                // 🎯 Filtre direct sur le country (dans Area)
                queryLocalName.Criteria.AddCondition(
                    "ctx_countryid",
                    ConditionOperator.Equal,
                    countryId  // GUID
                );

                queryLocalName.Criteria.AddCondition(
                       "ctx_productid",
                       ConditionOperator.Equal,
                       productId   // GUID
                   );

                EntityCollection productTranslations = service.RetrieveMultiple(queryLocalName);

                log.Trace("Finish de GetProductTranslationName count : {0}", productTranslations.Entities.Count);

                return productTranslations.Entities.FirstOrDefault();



            }
            catch (Exception ex)
            {
                log.Trace($"An unexpected error occurred in the ProductTranslation GetProductTranslationName: {ex.Message}");
                throw new InvalidPluginExecutionException($"An unexpected error occurred in the ProductTranslation GetProductTranslationName : {ex.Message}");
            }
        }
    }
}
