﻿using Centrix.CRM.Model;
using CentrixBI_OneShot.DataMigration;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Description;
using static CentrixBI_OneShot.QuoteTemplate.QuoteTemplateHelper;

namespace CentrixBI_OneShot.QuoteTemplate
{
    public static class GenerateTemplateDynamicsStrucutre
    {
        private const string FamilyAlias = "familyproduct";

        public static Guid quoteid = new Guid("941f0ec7-d0ce-f111-a05c-3833c5cfde68");
        public static void Execute(CrmServiceClient service, ref TraceLogger log)
        {
            log.Trace("----------------- GenerateTemplateDynamicStructure -----------------");
            try
            {
                Quote quote = service.Retrieve("quote", quoteid, new ColumnSet(true)).ToEntity<Quote>();
                EntityReference PriceLevelId = quote.PriceLevelId;
                Console.WriteLine("Execute Old/New Function ? 1/2");
                GenerateQuoteMatrixJson(service, ref log, quote, PriceLevelId);
                //  
            }
            catch (Exception ex)
            {
                // Toute exception (y compris hors GenerateQuoteMatrixJson) → quote template d'erreur, sans bloquer l'utilisateur
                log.Trace($"An unexpected error occurred in the plugin GenerateTemplateDynamicStructure : {ex.Message}");
                HandleException(service, ref log, quoteid, ex);
            }
            finally
            {
                log.Trace("Finish GenerateTemplateDynamicStructure..");
            }
        }

        private static void GenerateQuoteMatrixJson(IOrganizationService service, ref TraceLogger log, Entity quote, EntityReference priceLevelRef)
        {
            try
            {
                GenerateQuoteMatrixJsonCore(service, ref log, quote, priceLevelRef);
            }
            catch (Exception ex)
            {
                HandleException(service, ref log, quote.Id, ex);
                // Sortie normale du plugin : pas d'exception → l'utilisateur CRM n'est pas bloqué
            }
        }

        private static void GenerateQuoteMatrixJsonCore(IOrganizationService service, ref TraceLogger log, Entity quote, EntityReference priceLevelRef)
        {

            log.Trace("-----------------start GenerateQuoteMatrixJson -----------------");
            List<Entity> quoteTemplateList = new List<Entity>();

            // Templates créés par le traitement des bundles : exclus du contrôle doublon
            var bundleTemplates = new HashSet<Entity>();

            #region 🔥 SUPPRESSION des anciennes lignes de template
            var deleteQuery = new QueryExpression("ctx_quotetemplate")
            {
                ColumnSet = new ColumnSet("ctx_quotetemplateid"), // obligatoire pour delete
                Criteria =
    {
        Conditions =
        {
            new ConditionExpression("ctx_quoteid", ConditionOperator.Equal, quote.Id)
        }
    }
            };

            var existingTemplates = service.RetrieveMultiple(deleteQuery).Entities;

            foreach (var record in existingTemplates)
            {
                service.Delete("ctx_quotetemplate", record.Id);
            }
            #endregion

            Func<Entity, int?> ResolveZone = e =>
            {
                if (e.Contains("ctx_arealocalprice")) return 961410000;
                if (e.Contains("ctx_area1price")) return 961410001;
                if (e.Contains("ctx_area2price")) return 961410002;
                if (e.Contains("ctx_area3price")) return 961410003;
                if (e.Contains("ctx_area4price")) return 961410004;
                if (e.Contains("ctx_area5price")) return 961410005;
                return null;
            };


            #region 0. Pays de la liste de prix + résolution des produits additionnels (nom produit / FetchXml du paramétrage)
            EntityReference priceLevelCountryRef = null;

            try
            {
                if (priceLevelRef == null)
                {
                    throw new InvalidPluginExecutionException("The quote has no price list (pricelevelid) — bundle processing skipped");
                }
                var priceLevelEntity = service.Retrieve("pricelevel", priceLevelRef.Id, new ColumnSet("ctx_countryid"));
                priceLevelCountryRef = priceLevelEntity.GetAttributeValue<EntityReference>("ctx_countryid");
            }
            catch (Exception)
            {
                // si l'appel échoue on continue sans country (le fallback géré plus bas)
                priceLevelCountryRef = null;
            }

            string priceLevelCountryName = priceLevelCountryRef?.Name;
            log.Trace($"Pays de la liste de prix : {priceLevelCountryName ?? "non défini"}");

            // Règles applicables au pays (dans l'ordre du paramétrage). Seules les règles avec FetchXml font un appel serveur.
            var additionalRules = ResolveAdditionalProductRules(service, ref log, priceLevelCountryName, quote.Id, priceLevelRef?.Id);

            // Première règle qui correspond (GUID issu d'un FetchXml OU nom du produit), null sinon
            Func<Guid?, string, AdditionalProductRule> FindAdditionalRule = (productId, productName) =>
                additionalRules.FirstOrDefault(r => r.Matches(productId, productName))?.Rule;
            #endregion


            #region 1. Récupérer les lignes de devis avec infos produit + zone Hors Bundle
            var quoteDetailColumns = new List<string> { "productid", "productname", "extendedamount", "ctx_areacpqid", "priceperunit", "ctx_unitpriceafterdiscount", "producttypecode",
                "isproductoverridden", "productdescription" }; // produits hors catalogue

            // Ajouter les champs "valeur" déclarés dans le paramétrage des produits additionnels
            foreach (var field in additionalRules
                .Select(a => a.Rule.ValueFieldName)
                .Where(f => !string.IsNullOrWhiteSpace(f))
                .Select(f => f.Trim().ToLowerInvariant())
                .Distinct())
            {
                if (!quoteDetailColumns.Contains(field)) quoteDetailColumns.Add(field);
            }

            var query = new QueryExpression("quotedetail");
            query.ColumnSet.AddColumns(quoteDetailColumns.ToArray());

            var query_And1 = new FilterExpression();
            query.Criteria.AddFilter(query_And1);
            query_And1.AddCondition("producttypecode", ConditionOperator.NotIn, 3, 4);
            query_And1.AddCondition("quoteid", ConditionOperator.Equal, quote.Id);

            // quotedetail → product (alias "product")
            // LeftOuter : on garde les lignes sans produit lié (write-in)
            var query_product = query.AddLink("product", "productid", "productid", JoinOperator.LeftOuter);
            query_product.EntityAlias = "product";
            query_product.Columns.AddColumns("productid", "name", "parentproductid", QuoteTemplateFields.ProductExternalId);

            // product → produit parent / famille (alias "familyproduct")
            // LeftOuter : on garde les produits sans parent (bundles, produits additionnels…)
            var query_product_product = query_product.AddLink("product", "parentproductid", "productid", JoinOperator.LeftOuter);
            query_product_product.EntityAlias = "familyproduct";
            query_product_product.Columns.AddColumns(QuoteTemplateFields.ProductPlatformList, "name", "productid", "parentproductid", QuoteTemplateFields.ProductExternalId);


            var lines = service.RetrieveMultiple(query).Entities;

            // Cache produit (hiérarchie ctx_externalid) pré-alimenté avec le produit et son parent déjà lus par la requête
            var productCache = new Dictionary<Guid, Entity>();
            var resolvedProductNames = new Dictionary<Guid, string>();
            foreach (var line in lines)
            {
                CacheProductFromAlias(productCache, line, "product");
                CacheProductFromAlias(productCache, line, "familyproduct");
            }

            // 2. Transformer en structure simple
            var data = lines.Select(x =>
            {
                // Produit du devis
                var productRef = x.GetAttributeValue<EntityReference>("productid");
                string productName = productRef?.Name;

                // Nom utilisé pour les règles "ProductNames" : quotedetail.productname (sinon nom du produit lié)
                string lineProductName = x.GetAttributeValue<string>("productname");
                if (string.IsNullOrWhiteSpace(lineProductName)) lineProductName = productName;

                // Produit parent = familyproduct.name (null si le produit n'a pas de parent)

                string parentName = GetAliasedValue<string>(x, "familyproduct.name");
                if (string.IsNullOrWhiteSpace(parentName)) parentName = null;

                Guid? parentId = GetAliasedValue<Guid?>(x, "familyproduct.productid");


                Entity zoneEntity = new Entity();

                var areaRef = x.GetAttributeValue<EntityReference>("ctx_areacpqid");
                if (areaRef != null)
                {
                    zoneEntity = service.Retrieve("ctx_areacpq", areaRef.Id, new ColumnSet("ctx_areanumber"));
                }

                return new
                {
                    Produit = parentName ?? productName, // ✅ clé métier
                    ParentProductId = parentId,
                    Zone = zoneEntity?.GetAttributeValue<OptionSetValue>("ctx_areanumber")?.Value,
                    Prix = Math.Round(x.GetAttributeValue<Money>("ctx_unitpriceafterdiscount")?.Value ?? 0, 2),
                    ProductTypeCode = x.GetAttributeValue<OptionSetValue>("producttypecode")?.Value,   // 2 = Bundle
                    ProductId = productRef?.Id,
                    Line = x,
                    LineProductName = lineProductName, // quotedetail.productname (sinon nom du produit lié)
                    Platfrom = GetMultiSelectLabel(x, "familyproduct." + QuoteTemplateFields.ProductPlatformList), // libellé ctx_platformlist du produit parent (null si absent)
                    IsWriteIn = x.GetAttributeValue<bool?>("isproductoverridden") == true,     // produit hors catalogue
                    ProductDescription = x.GetAttributeValue<string>("productdescription"),   // nom du produit hors catalogue
                    AdditionalRule = FindAdditionalRule(productRef?.Id, lineProductName)
                };
            }).ToList();

            // Produits hors catalogue (isproductoverridden = true) : traités séparément (voir plus bas)
            var writeInItems = data
                .Where(x => x.IsWriteIn)
                .ToList();
            log.Trace($"Lignes de devis hors catalogue : {writeInItems.Count}");

            // Isolation des produits additionnels : nom du produit OU productid présent dans le résultat d'un FetchXml
            var additionalProductItems = data
                .Where(x => !x.IsWriteIn && x.AdditionalRule != null)
                .ToList();
            log.Trace($"Lignes de devis identifiées comme produits additionnels : {additionalProductItems.Count}");

            // Lignes "normales" = tout sauf les produits additionnels
            var regularData = data
                .Where(x => !x.IsWriteIn && x.AdditionalRule == null)
                .ToList();

            // Nom des produits (hors bundles) : 1er produit de la hiérarchie (lui-même, parent, grand-parent…) ayant un ctx_externalid.
            //    Si aucun nom n'est trouvé → la ligne est EXCLUE (pas de quote template, pas de contrôle doublon).
            foreach (var item in regularData.Where(x => x.ProductTypeCode != 2 && x.ProductId.HasValue))
            {
                if (!resolvedProductNames.ContainsKey(item.ProductId.Value))
                    resolvedProductNames[item.ProductId.Value] = ResolveProductNameByExternalId(service, ref log, item.ProductId.Value, productCache);
            }

            var catalogData = regularData
                .Where(x => x.ProductTypeCode != 2) // exclure les bundles (traités séparément)
                .Select(x => new
                {
                    Item = x,
                    ResolvedName = x.ProductId.HasValue ? resolvedProductNames[x.ProductId.Value] : null
                })
                .ToList();

            foreach (var excluded in catalogData.Where(c => string.IsNullOrWhiteSpace(c.ResolvedName)))
            {
                log.Trace($"Produit '{excluded.Item.LineProductName}' exclu : aucun ctx_externalid dans sa hiérarchie");
            }

            catalogData = catalogData.Where(c => !string.IsNullOrWhiteSpace(c.ResolvedName)).ToList();

            var produits = catalogData
                .Select(c => c.ResolvedName)
                .Distinct()
                .ToList();

            foreach (var produit in produits)
            {
                var items = catalogData.Where(c => c.ResolvedName == produit).Select(c => c.Item).ToList();

                // ✅ contrôle doublon (Produit + Zone)
                var duplicates = items
                    .GroupBy(x => x.Zone)
                    .Where(g => g.Count() > 1);

                if (duplicates.Any())
                {
                    throw new QuoteTemplateFunctionalException(
                        QuoteTemplateErrors.DoublonProduitZone,
                        $"Duplicate detected for product '{produit}' in zone '{duplicates.First().Key}': several quote lines exist for the same product and the same zone."
                    );
                }

                var entity = new Entity("ctx_quotetemplate");

                entity["ctx_name"] = produit;

                // Famille de produit = libellé(s) ctx_platformlist des produits de la ligne
                foreach (var item in items) AddProductFamily(entity, item.Platfrom);

                // ✅ liaison au devis
                entity["ctx_quoteid"] = new EntityReference("quote", quote.Id);

                foreach (var item in items)
                {

                    if (item.ParentProductId != null)
                    {
                        Guid parentProductId = item.ParentProductId.Value;
                        string productCountryName = ProductTranslation.GetProductTranslationName(service, priceLevelCountryRef.Id,parentProductId, log)?.GetAttributeValue<string>("ctx_name");
                        entity["ctx_productcountryname"] = !string.IsNullOrEmpty(productCountryName) ? productCountryName : produit;
                        log.Trace($"Processed parent product ID: {parentProductId}");

                    }


                    switch (item.Zone)
                    {
                        case 961410000:
                            entity["ctx_arealocalprice"] = item.Prix.ToString();
                            break;

                        case 961410001:
                            entity["ctx_area1price"] = item.Prix.ToString();
                            break;

                        case 961410002:
                            entity["ctx_area2price"] = item.Prix.ToString();
                            break;

                        case 961410003:
                            entity["ctx_area3price"] = item.Prix.ToString();
                            break;

                        case 961410004:
                            entity["ctx_area4price"] = item.Prix.ToString();
                            break;

                        case 961410005:
                            entity["ctx_area5price"] = item.Prix.ToString();
                            break;
                    }

                }

                // ✅ FILTRE : exclure lignes vides
                bool hasAtLeastOneValue =
                    entity.Contains("ctx_arealocalprice") ||
                    entity.Contains("ctx_area1price") ||
                    entity.Contains("ctx_area2price") ||
                    entity.Contains("ctx_area3price") ||
                    entity.Contains("ctx_area4price") ||
                    entity.Contains("ctx_area5price");

                if (!hasAtLeastOneValue)
                {
                    log.Trace($"Produit '{produit}' ignoré (aucune zone renseignée)");
                    continue;
                }
                quoteTemplateList.Add(entity);
            }
            #endregion

            #region  Traitement des bundles (producttypecode = 2)
            var bundleLines = regularData.Where(x => x.ProductTypeCode == 2 && x.ProductId.HasValue).ToList();
            log.Trace($"Bundles trouvés : {bundleLines.Count}");

            if (bundleLines.Any())
            {
                // Récupérer la liste de prix du devis (pricelevelid)
                if (priceLevelRef == null)
                {
                    throw new QuoteTemplateFunctionalException(
                        QuoteTemplateErrors.ListePrixManquante,
                        $"The quote contains {bundleLines.Count} bundle(s) but has no price list (pricelevelid): bundle products cannot be retrieved."
                    );
                }

                log.Trace($"Price Level : {priceLevelRef.Id}");
                var processedBundleProducts = new HashSet<Guid>();



                foreach (var bundleLine in bundleLines)
                {
                    if (processedBundleProducts.Contains(bundleLine.ProductId.Value))
                    {
                        log.Trace($"Bundle '{bundleLine.Produit}' déjà traité — ignoré");
                        continue;
                    }
                    processedBundleProducts.Add(bundleLine.ProductId.Value);

                    // 1️⃣ Vérifier que le productpricelevel du bundle a ctx_pricelistitemtypecode = 961410003
                    var checkQuery = new QueryExpression("productpricelevel")
                    {
                        ColumnSet = new ColumnSet("productpricelevelid"),
                        TopCount = 1,
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("pricelevelid", ConditionOperator.Equal, priceLevelRef.Id),
                                    new ConditionExpression("productid",    ConditionOperator.Equal, bundleLine.ProductId.Value),
                                    new ConditionExpression("ctx_pricelistitemtypecode", ConditionOperator.Equal, (int)CTx_PriceListItemTypeCode.AllPriceListProduct)
                                }
                            }
                    };

                    var checkResult = service.RetrieveMultiple(checkQuery).Entities;

                    if (!checkResult.Any())
                    {
                        log.Trace($"Bundle '{bundleLine.Produit}' : pas de productpricelevel de type 961410003 → ignoré");
                        continue;
                    }

                    log.Trace($"Bundle '{bundleLine.Produit}' : condition 961410003 validée → récupération des lignes type 961410000");

                    // 2️⃣ Récupérer tous les productpricelevel de la même pricelevel avec ctx_pricelistitemtypecode = 961410000
                    //     + le produit parent de chaque produit (jointure product → parentproductid)
                    var pplQuery = new QueryExpression("productpricelevel")
                    {
                        ColumnSet = new ColumnSet("productid", "amount"),
                        Criteria =
                            {
                                Conditions =
                                {
                                    new ConditionExpression("pricelevelid", ConditionOperator.Equal, priceLevelRef.Id),
                                    new ConditionExpression("ctx_pricelistitemtypecode", ConditionOperator.Equal, 961410000)
                                }
                            },
                        LinkEntities =
                            {
                                new LinkEntity
                                {
                                    LinkFromEntityName    = "productpricelevel",
                                    LinkFromAttributeName = "productid",
                                    LinkToEntityName      = "product",
                                    LinkToAttributeName   = "productid",
                                    JoinOperator          = JoinOperator.Inner,
                                    Columns               = new ColumnSet("productid", "name", "parentproductid", QuoteTemplateFields.ProductPlatformList, QuoteTemplateFields.ProductExternalId),
                                    EntityAlias           = "pplprod",
                                    // Uniquement les produits dont ctx_platformlist contient une des valeurs paramétrées
                                    LinkCriteria =
                                    {
                                        Conditions =
                                        {
                                            new ConditionExpression(QuoteTemplateFields.ProductPlatformList, ConditionOperator.ContainValues,
                                                QuoteTemplateFields.BundlePlatformListValues.Cast<object>().ToArray())
                                        }
                                    }
                                }
                            }
                    };

                    var pplRecords = service.RetrieveMultiple(pplQuery).Entities;

                    // Cache produit pré-alimenté avec les produits lus (évite un Retrieve pour le 1er niveau)
                    foreach (var pplRecord in pplRecords)
                    {
                        CacheProductFromAlias(productCache, pplRecord, "pplprod");
                    }
                    log.Trace($"Productpricelevel (type 961410000) récupérés : {pplRecords.Count}");

                    // 3️⃣ Créer un ctx_quotetemplate par productpricelevel, avec la zone du bundle.
                    //     La zone est toujours résolue via la relation produit->ctx_productareacpq->ctx_areacpq (avec ctx_owningcountry == pricelevel.ctx_countryid)
                    foreach (var ppl in pplRecords)
                    {
                        var pplProductRef = ppl.GetAttributeValue<EntityReference>("productid");
                        var pplAmount = Math.Round(ppl.GetAttributeValue<Money>("amount")?.Value ?? 0, 2);

                        // Nom du produit = 1er produit de la hiérarchie (lui-même, parent, grand-parent…) ayant un ctx_externalid
                        string bundleProductName = null;
                        if (pplProductRef != null)
                        {
                            if (!resolvedProductNames.TryGetValue(pplProductRef.Id, out bundleProductName))
                            {
                                bundleProductName = ResolveProductNameByExternalId(service, ref log, pplProductRef.Id, productCache);
                                resolvedProductNames[pplProductRef.Id] = bundleProductName;
                            }
                        }

                        // Aucun nom trouvé → produit EXCLU (pas de quote template)
                        if (string.IsNullOrWhiteSpace(bundleProductName))
                        {
                            log.Trace($"Produit '{pplProductRef?.Name}' (bundle) exclu : aucun ctx_externalid dans sa hiérarchie");
                            continue;
                        }

                        // Produit additionnel → jamais de ligne ctx_quotetemplate
                        if (pplProductRef != null && FindAdditionalRule(pplProductRef.Id, pplProductRef.Name) != null)
                        {
                            log.Trace($"Produit '{pplProductRef.Name}' (bundle) ignoré : produit additionnel");
                            continue;
                        }

                        // Toujours calculer la zone via ctx_productareacpq -> ctx_areacpq
                        int? zoneVal = null;

                        if (priceLevelCountryRef != null)
                        {
                            try
                            {
                                // Requête : ctx_productareacpq join ctx_areacpq filtrée sur ctx_owningcountry = pricelevel.ctx_countryid
                                var prodAreaQuery = new QueryExpression(CTx_AreAcPQ.EntityLogicalName);
                                prodAreaQuery.TopCount = 1;
                                prodAreaQuery.ColumnSet.AddColumns(CTx_AreAcPQ.Fields.CTx_AreaNumber, CTx_AreAcPQ.Fields.CTx_OwningCountry);
                                prodAreaQuery.Criteria.AddCondition(CTx_AreAcPQ.Fields.CTx_OwningCountry, ConditionOperator.Equal, priceLevelCountryRef.Id);
                                var query_ctx_productareacpq = prodAreaQuery.AddLink(
                                    CTx_ProductAreAcPQ.EntityLogicalName,
                                    CTx_AreAcPQ.PrimaryIdAttribute,
                                    CTx_ProductAreAcPQ.Fields.CTx_AreAcPQId);

                                var query_ctx_productareacpq_product = query_ctx_productareacpq.AddLink(
                                    Product.EntityLogicalName,
                                    CTx_ProductAreAcPQ.Fields.CTx_ProductId,
                                    Product.PrimaryIdAttribute);

                                query_ctx_productareacpq_product.LinkCriteria.AddCondition(Product.PrimaryIdAttribute, ConditionOperator.Equal, pplProductRef.Id);

                                var prodAreaRecords = service.RetrieveMultiple(prodAreaQuery).Entities;
                                if (prodAreaRecords.Any() && prodAreaRecords[0].Contains("ctx_areanumber"))
                                {
                                    var areaOption = (OptionSetValue)prodAreaRecords[0]["ctx_areanumber"];
                                    zoneVal = areaOption?.Value;
                                    log.Trace($"Zone calculée pour bundle '{bundleLine.Produit}' via ctx_productareacpq -> ctx_areacpq = {zoneVal}");
                                }
                                else
                                {
                                    log.Trace($"Aucun ctx_areacpq trouvé pour le produit '{bundleLine.Produit}' et le pays pricelist '{priceLevelCountryRef.Name ?? priceLevelCountryRef.Id.ToString()}'");
                                }
                            }
                            catch (Exception ex)
                            {
                                log.Trace($"Erreur lors de la résolution de la zone pour '{bundleLine.Produit}' : {ex.Message}");
                            }
                        }
                        else
                        {
                            log.Trace($"Impossible de résoudre la zone pour '{bundleLine.Produit}' : ctx_country du pricelevel non défini");
                        }

                        // Zone du produit → champ de prix correspondant
                        if (!zoneVal.HasValue)
                        {
                            log.Trace($"Zone inconnue pour '{bundleProductName}' (produit '{pplProductRef?.Name}') — ignoré");
                            continue;
                        }

                        string zoneField;
                        switch (zoneVal.Value)
                        {
                            case 961410000: zoneField = "ctx_arealocalprice"; break;
                            case 961410001: zoneField = "ctx_area1price"; break;
                            case 961410002: zoneField = "ctx_area2price"; break;
                            case 961410003: zoneField = "ctx_area3price"; break;
                            case 961410004: zoneField = "ctx_area4price"; break;
                            case 961410005: zoneField = "ctx_area5price"; break;
                            default:
                                log.Trace($"Zone inconnue '{zoneVal.Value}' pour '{bundleProductName}' (produit '{pplProductRef?.Name}') — ignoré");
                                continue;
                        }

                        // ✅ Un seul ctx_quotetemplate par famille (produit parent) :
                        //    on réutilise l'enregistrement existant de même nom et on y ajoute le prix de la zone
                        var templateEntity = quoteTemplateList.FirstOrDefault(x => x.GetAttributeValue<string>("ctx_name") == bundleProductName);
                        bool isNewTemplate = templateEntity == null;

                        if (isNewTemplate)
                        {
                            templateEntity = new Entity("ctx_quotetemplate");
                            templateEntity["ctx_name"] = bundleProductName; // nom du produit parent
                            string productCountryName = ProductTranslation.GetProductTranslationName(service, priceLevelCountryRef.Id, pplProductRef.Id, log)?.GetAttributeValue<string>("ctx_name");
                            templateEntity["ctx_productcountryname"] = !string.IsNullOrEmpty(productCountryName) ? productCountryName: bundleProductName;
                            templateEntity["ctx_quoteid"] = new EntityReference("quote", quote.Id);
                        }
                        else if (templateEntity.Contains(zoneField))
                        {
                            // Zone déjà renseignée pour cette famille → on garde le premier prix
                            log.Trace($"Famille '{bundleProductName}' : zone '{zoneVal.Value}' déjà renseignée ({templateEntity[zoneField]}) — produit '{pplProductRef?.Name}' ({pplAmount}) ignoré");
                            continue;
                        }

                        templateEntity[zoneField] = pplAmount.ToString();

                        // Famille de produit = libellé(s) ctx_platformlist du produit
                        AddProductFamily(templateEntity, GetMultiSelectLabel(ppl, "pplprod." + QuoteTemplateFields.ProductPlatformList));

                        if (isNewTemplate)
                        {
                            quoteTemplateList.Add(templateEntity);
                            bundleTemplates.Add(templateEntity);
                            log.Trace($"ctx_quotetemplate créé (bundle) : '{bundleProductName}' — produit '{pplProductRef?.Name}' — {zoneField}={pplAmount}");
                        }
                        else
                        {
                            log.Trace($"ctx_quotetemplate complété (bundle) : '{bundleProductName}' — produit '{pplProductRef?.Name}' — {zoneField}={pplAmount}");
                        }
                    }
                }
            }
            #endregion


            #region ✅ contrôle doublon (Produit + Zone)

            // Pas de contrôle doublon sur les produits bundles
            var duplicatesBundles = quoteTemplateList
                .Where(x => !bundleTemplates.Contains(x))
                .GroupBy(x => new { Produit = x["ctx_name"], Zone = ResolveZone(x) })
                .Where(g => g.Count() > 1);

            if (duplicatesBundles.Any())
            {
                var first = duplicatesBundles.First();
                throw new QuoteTemplateFunctionalException(
                    QuoteTemplateErrors.DoublonProduitZone,
                    $"Duplicate detected for product '{first.Key.Produit}' in zone '{first.Key.Zone}': several quote templates exist for the same product and the same zone."
                );
            }
            #endregion

            quoteTemplateList = quoteTemplateList.OrderBy(x => x.GetAttributeValue<string>("ctx_productfamily")).ThenBy(x => x.GetAttributeValue<string>("ctx_name")).ToList();
            foreach (var template in quoteTemplateList)
            {
                service.Create(template);
                log.Trace($"ctx_quotetemplate créé : '{template["ctx_name"]}'");
            }

            #region Traitement post-création : produits additionnels (via AdditionalProductsConfig)
            if (additionalProductItems.Any())
            {
                log.Trace($"Traitement des produits additionnels ({additionalProductItems.Count} item(s))...");

                // Récupérer le 1er ctx_quotetemplate lié au quote (par createdon)
                var firstTemplateQuery = new QueryExpression("ctx_quotetemplate")
                {
                    ColumnSet = new ColumnSet("ctx_quotetemplateid"),
                    Criteria =
                    {
                        Conditions =
                        {
                            new ConditionExpression("ctx_quoteid", ConditionOperator.Equal, quote.Id)
                        }
                    },
                    TopCount = 1,
                    Orders =
                    {
                        new OrderExpression("createdon", OrderType.Ascending)
                    }
                };

                var firstTemplates = service.RetrieveMultiple(firstTemplateQuery).Entities;

                if (firstTemplates.Any())
                {
                    var firstTemplate = firstTemplates[0];
                    var updateEntity = new Entity("ctx_quotetemplate", firstTemplate.Id);

                    // Cache type des champs (Currency ?) + symbole de devise du devis (chargé une seule fois, si besoin)
                    var moneyFieldCache = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
                    string currencySymbol = null;
                    bool currencySymbolLoaded = false;

                    foreach (var item in additionalProductItems)
                    {
                        var match = item.AdditionalRule;
                        int slot = match.AdditionalProductNum;

                        if (slot < AdditionalProductsConfig.MinSlot || slot > AdditionalProductsConfig.MaxSlot)
                        {
                            log.Trace($"Produit '{item.Produit}' : slot {slot} hors plage [{AdditionalProductsConfig.MinSlot}-{AdditionalProductsConfig.MaxSlot}] — ignoré");
                            continue;
                        }

                        string nameField = AdditionalProductsConfig.GetNameField(slot);
                        string valueField = AdditionalProductsConfig.GetValueField(slot);
                        string value;
                        if (IsCurrencyField(service, ref log, item.Line, match.ValueFieldName, moneyFieldCache))
                        {
                            if (!currencySymbolLoaded)
                            {
                                currencySymbol = GetQuoteCurrencySymbol(service, ref log, quote.Id);
                                currencySymbolLoaded = true;
                            }
                            value = FormatCurrencyValue(item.Line, match.ValueFieldName, currencySymbol);
                        }
                        else
                        {
                            value = GetFieldValueAsText(item.Line, match.ValueFieldName);
                        }

                        if (updateEntity.Contains(nameField))
                        {
                            log.Trace($"⚠️ Slot {slot} déjà rempli par '{updateEntity[nameField]}' — écrasé par '{item.LineProductName}'");
                        }

                        // Nom = quotedetail.productname (fallback : nom du produit lié)
                        updateEntity[nameField] = item.LineProductName;
                        updateEntity[valueField] = value;
                        log.Trace($"Slot {slot} → '{item.LineProductName}' = '{value}' (champ source : {match.ValueFieldName})");
                    }

                    service.Update(updateEntity);
                    log.Trace($"Produits additionnels mis à jour sur ctx_quotetemplate {firstTemplate.Id}");
                }
                else
                {
                    log.Trace("Aucun ctx_quotetemplate trouvé pour le quote — produits additionnels ignorés");
                }
            }
            #endregion

            #region Produits hors catalogue (isproductoverridden = true) — traités en DERNIER
            // Après tous les autres produits (catalogue, bundles, produits additionnels).
            // Un ctx_quotetemplate par ligne hors catalogue, même prix dans toutes les zones, sans contrôle doublon.
            foreach (var item in writeInItems)
            {
                // Nom : productname, sinon productdescription, sinon nom par défaut
                string writeInName = item.Line.GetAttributeValue<string>("productname");
                if (string.IsNullOrWhiteSpace(writeInName)) writeInName = item.ProductDescription;
                if (string.IsNullOrWhiteSpace(writeInName)) writeInName = QuoteTemplateFields.WriteInDefaultName;
                writeInName = writeInName.Trim();

                if (writeInName.Length > QuoteTemplateFields.NameMaxLength)
                {
                    log.Trace($"Hors catalogue : nom tronqué à {QuoteTemplateFields.NameMaxLength} caractères ('{writeInName}')");
                    writeInName = writeInName.Substring(0, QuoteTemplateFields.NameMaxLength);
                }

                string price = item.Prix.ToString(); // ctx_unitpriceafterdiscount (0 si NULL)

                var writeInTemplate = new Entity("ctx_quotetemplate");
                writeInTemplate["ctx_name"] = writeInName;
                writeInTemplate["ctx_productcountryname"] = writeInName;
                writeInTemplate["ctx_quoteid"] = new EntityReference("quote", quote.Id);
                writeInTemplate["ctx_arealocalprice"] = price;
                //writeInTemplate["ctx_area1price"] = price;
                //writeInTemplate["ctx_area2price"] = price;
                //writeInTemplate["ctx_area3price"] = price;
                //writeInTemplate["ctx_area4price"] = price;
                //writeInTemplate["ctx_area5price"] = price;

                service.Create(writeInTemplate);
                log.Trace($"ctx_quotetemplate créé (hors catalogue) : '{writeInName}' — prix={price} (toutes zones)");
            }
            #endregion

            log.Trace("-----------------Finish GenerateQuoteMatrixJson -----------------");
        }
    }
}